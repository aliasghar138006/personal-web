exports.id = 917;
exports.ids = [917];
exports.modules = {

/***/ 1912:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "R": () => (/* binding */ DataContext),
  "Z": () => (/* binding */ context_Context)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./pages/_app.js + 2 modules
var _app = __webpack_require__(7017);
// EXTERNAL MODULE: ./public/icons/Home.js
var Home = __webpack_require__(356);
;// CONCATENATED MODULE: ./public/icons/AboutUs.js


function AboutUs() {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        strokeWidth: 1.5,
        stroke: "currentColor",
        className: "w-6 h-6",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M15 9h3.75M15 12h3.75M15 15h3.75M4.5 19.5h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5zm6-10.125a1.875 1.875 0 11-3.75 0 1.875 1.875 0 013.75 0zm1.294 6.336a6.721 6.721 0 01-3.17.789 6.721 6.721 0 01-3.168-.789 3.376 3.376 0 016.338 0z"
        })
    });
}
/* harmony default export */ const icons_AboutUs = (AboutUs);

;// CONCATENATED MODULE: ./public/icons/Documents.js


function Documents() {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        strokeWidth: 1.5,
        stroke: "currentColor",
        className: "w-6 h-6",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z"
        })
    });
}
/* harmony default export */ const icons_Documents = (Documents);

;// CONCATENATED MODULE: ./public/icons/Commendations.js


function Commendations() {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        strokeWidth: 1.5,
        stroke: "currentColor",
        className: "w-6 h-6",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"
        })
    });
}
/* harmony default export */ const icons_Commendations = (Commendations);

;// CONCATENATED MODULE: ./public/icons/Simples.js


function Simples() {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        strokeWidth: 1.5,
        stroke: "currentColor",
        className: "w-6 h-6",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M20.25 14.15v4.25c0 1.094-.787 2.036-1.872 2.18-2.087.277-4.216.42-6.378.42s-4.291-.143-6.378-.42c-1.085-.144-1.872-1.086-1.872-2.18v-4.25m16.5 0a2.18 2.18 0 00.75-1.661V8.706c0-1.081-.768-2.015-1.837-2.175a48.114 48.114 0 00-3.413-.387m4.5 8.006c-.194.165-.42.295-.673.38A23.978 23.978 0 0112 15.75c-2.648 0-5.195-.429-7.577-1.22a2.016 2.016 0 01-.673-.38m0 0A2.18 2.18 0 013 12.489V8.706c0-1.081.768-2.015 1.837-2.175a48.111 48.111 0 013.413-.387m7.5 0V5.25A2.25 2.25 0 0013.5 3h-3a2.25 2.25 0 00-2.25 2.25v.894m7.5 0a48.667 48.667 0 00-7.5 0M12 12.75h.008v.008H12v-.008z"
        })
    });
}
/* harmony default export */ const icons_Simples = (Simples);

;// CONCATENATED MODULE: ./public/icons/Courses.js


function Courses() {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        strokeWidth: 1.5,
        stroke: "currentColor",
        className: "w-6 h-6",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            strokeLinecap: "round",
            d: "M15.75 10.5l4.72-4.72a.75.75 0 011.28.53v11.38a.75.75 0 01-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 002.25-2.25v-9a2.25 2.25 0 00-2.25-2.25h-9A2.25 2.25 0 002.25 7.5v9a2.25 2.25 0 002.25 2.25z"
        })
    });
}
/* harmony default export */ const icons_Courses = (Courses);

;// CONCATENATED MODULE: ./public/icons/Contact.js


function Contact() {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        strokeWidth: 1.5,
        stroke: "currentColor",
        className: "w-6 h-6",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M14.25 9.75v-4.5m0 4.5h4.5m-4.5 0l6-6m-3 18c-8.284 0-15-6.716-15-15V4.5A2.25 2.25 0 014.5 2.25h1.372c.516 0 .966.351 1.091.852l1.106 4.423c.11.44-.054.902-.417 1.173l-1.293.97a1.062 1.062 0 00-.38 1.21 12.035 12.035 0 007.143 7.143c.441.162.928-.004 1.21-.38l.97-1.293a1.125 1.125 0 011.173-.417l4.423 1.106c.5.125.852.575.852 1.091V19.5a2.25 2.25 0 01-2.25 2.25h-2.25z"
        })
    });
}
/* harmony default export */ const icons_Contact = (Contact);

;// CONCATENATED MODULE: ./context/Context.js










const DataContext = /*#__PURE__*/ (0,external_react_.createContext)(null);
function Context({ children  }) {
    const menuData = [
        {
            id: 1,
            title: "خانه",
            name: "home",
            icon: /*#__PURE__*/ jsx_runtime_.jsx(Home/* default */.Z, {})
        },
        {
            id: 2,
            title: "درباره من",
            name: "about-me",
            icon: /*#__PURE__*/ jsx_runtime_.jsx(icons_AboutUs, {})
        },
        {
            id: 3,
            title: "مدارک",
            name: "documents",
            icon: /*#__PURE__*/ jsx_runtime_.jsx(icons_Documents, {})
        },
        {
            id: 4,
            title: "تقدیرنامه ها",
            name: "commendations",
            icon: /*#__PURE__*/ jsx_runtime_.jsx(icons_Commendations, {})
        },
        {
            id: 5,
            title: "نمونه کارها",
            name: "simples",
            icon: /*#__PURE__*/ jsx_runtime_.jsx(icons_Simples, {})
        },
        {
            id: 6,
            title: "دوره ها",
            name: "coureses",
            icon: /*#__PURE__*/ jsx_runtime_.jsx(icons_Courses, {})
        },
        {
            id: 7,
            title: "ارتباط با من",
            name: "contact",
            icon: /*#__PURE__*/ jsx_runtime_.jsx(icons_Contact, {})
        }
    ];
    const skillsData = [
        {
            id: 1,
            title: "html",
            width: "100%"
        },
        {
            id: 2,
            title: "css",
            width: "100%"
        },
        {
            id: 3,
            title: "js",
            width: "90%"
        },
        {
            id: 4,
            title: "React",
            width: "90%"
        },
        {
            id: 5,
            title: "Next",
            width: "83%"
        },
        {
            id: 6,
            title: "python",
            width: "90%"
        },
        {
            id: 7,
            title: "Django",
            width: "90%"
        }
    ];
    const educationData = [
        {
            id: 1,
            title: "کاردانی مکانیک خودرو",
            university: "دانشکده فنی پسران سمنان",
            year: "1398"
        },
        {
            id: 2,
            title: "کارشناسی مکانیک خودرو",
            university: "دانشکده فنی پسران سمنان",
            year: "1400"
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx(DataContext.Provider, {
        value: {
            menuData,
            skillsData,
            educationData
        },
        children: children
    });
}
/* harmony default export */ const context_Context = (Context);


/***/ }),

/***/ 7017:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./context/Context.js + 6 modules
var Context = __webpack_require__(1912);
;// CONCATENATED MODULE: ./components/modules/Sidebar.js




function Sidebar({ open , setOpen  }) {
    const { menuData  } = (0,external_react_.useContext)(Context/* DataContext */.R);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "absolute md:block top-0 right-0 bg-[#0c0c14] h-[800px] w-[50%] sm:w-[25%] overflow-x-hidden z-20",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute -right-12 bg-[#2fbf71] w-[150%] h-[120px] rounded-b-[70%] z-0"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute top-[50px] right-[27%] bg-white w-[100px] h-[100px] border-[5px] border-s-violet-50 overflow-hidden rounded-full",
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "/images/aliasghar.jpg",
                    alt: "aliasghar",
                    className: "-my-2"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "absolute top-[170px] right-[30%] text-white",
                children: "علی اصغر شحنه"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "my-[250px] mr-5",
                children: menuData.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/${item.name}`,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex transition ease-in-out duration-1 items-center active:text-[#2cb66c] text-[#87878b] hover:text-white",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: " w-[30px] h-[30px]",
                                    children: item.icon
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "my-4 cursor-pointer mr-[10px]",
                                    children: item.title
                                })
                            ]
                        })
                    }, item.id))
            })
        ]
    });
}
/* harmony default export */ const modules_Sidebar = (Sidebar);

;// CONCATENATED MODULE: ./components/Layout/Layout.js



function Layout({ children  }) {
    const [open, setOpen] = (0,external_react_.useState)(false);
    const resizeHandler = ()=>{
        const width = window.innerWidth;
        if (width >= 768) {
            setOpen(true);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "font-laleh z-1000",
        onMouseEnter: resizeHandler,
        onClick: ()=>setOpen(!open),
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                id: "nav",
                className: "fixed md:hidden flex p-4 bg-[#10101a] top-0 w-full items-center z-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex-auto",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "text-white text-[25px]",
                            children: "علی اصغر شحنه"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "bg-[#2fbf71] p-3 rounded-full cursor-pointer w-fit h-[55px]",
                        onClick: ()=>setOpen(!open),
                        children: open ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-4",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-white w-8 h-0.5 my-1.5 rotate-45"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-white w-8 h-0.5 -my-2 -rotate-45"
                                })
                            ]
                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-white w-8 h-0.5 my-1.5"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-white w-8 h-0.5 my-1.5"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-white w-8 h-0.5 my-1.5"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    open ? /*#__PURE__*/ jsx_runtime_.jsx(modules_Sidebar, {}) : null,
                    children
                ]
            })
        ]
    });
}
/* harmony default export */ const Layout_Layout = (Layout);

;// CONCATENATED MODULE: ./pages/_app.js




function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(Context/* default */.Z, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Layout_Layout, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 356:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function Home() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        strokeWidth: 1.5,
        stroke: "currentColor",
        className: "w-6 h-6",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ })

};
;