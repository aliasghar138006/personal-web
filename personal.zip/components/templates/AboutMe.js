import Button from '../elements/Button'
import AboutSec from '../modules/AboutSec';
import MyEducation from '../modules/MyEducation';
import MyExprience from '../modules/MyExprience';
import MySkills from '../modules/MySkills';

function AboutMe() {
    return (
        <div className="my-[100px] mx-[10px] text-white">
           <AboutSec />
           <MySkills />
           <MyEducation />
           <MyExprience />
        </div>
    );
}

export default AboutMe;