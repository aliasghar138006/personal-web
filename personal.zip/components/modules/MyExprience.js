import React from 'react';
import Title from '../elements/Title';

function MyExprience(props) {
    return (
        <div>
            <Title title='تجربه ها' />
        </div>
    );
}

export default MyExprience;