import { createContext } from 'react';
import MyApp from '../pages/_app';
import Home from '../public/icons/Home';
import AboutUs from '../public/icons/AboutUs';
import Documents from '../public/icons/Documents';
import Commendations from '../public/icons/Commendations';
import Simples from '../public/icons/Simples';
import Courses from '../public/icons/Courses';
import Contact from '../public/icons/Contact';

export const DataContext = createContext(null)
function Context({children}) {
    const menuData = [
        {id:1 , title : "خانه" , name: 'home' , icon:<Home />},
        {id:2 , title : "درباره من" , name: 'about-me' , icon:<AboutUs />},
        {id:3 , title : "مدارک" , name: 'documents' , icon:<Documents />},
        {id:4 , title : "تقدیرنامه ها" , name: 'commendations' , icon:<Commendations />},
        {id:5 , title : "نمونه کارها" , name: 'simples' , icon:<Simples />},
        {id:6 , title : "دوره ها" , name: 'coureses' , icon:<Courses />},
        {id:7 , title : "ارتباط با من" , name: 'contact' , icon:<Contact />},
    ]

    const skillsData = [
        {id:1 , title:'html' , width:'100%'},
        {id:2 , title:'css' , width:'100%'},
        {id:3 , title:'js' , width:'90%'},
        {id:4 , title:'React' , width:'90%'},
        {id:5 , title:'Next' , width:'83%'},
        {id:6 , title:'python' , width:'90%'},
        {id:7 , title:'Django' , width:'90%'},
    ]

    const educationData = [
        {id:1 , title:'کاردانی مکانیک خودرو' , university:'دانشکده فنی پسران سمنان' , year:'1398'},
        {id:2 , title:'کارشناسی مکانیک خودرو' , university:'دانشکده فنی پسران سمنان' , year:'1400'},
    ]

    return (
        <DataContext.Provider value={{menuData , skillsData , educationData}}>
            {children}
        </DataContext.Provider>
    );
}

export default Context;