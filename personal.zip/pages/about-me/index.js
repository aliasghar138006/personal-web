import React from 'react';
import AboutMe from '../../components/templates/AboutMe';

function Index(props) {
    return (
        <div className='flex bg-[#10101a] h-full'>

            <AboutMe />
        </div>
    );
}

export default Index;